|    TAG    | COUNT |    AUTHOR     | COUNT |    DIRECTORY     | COUNT | SEVERITY | COUNT |  TYPE   | COUNT |
|-----------|-------|---------------|-------|------------------|-------|----------|-------|---------|-------|
| cve       |  1551 | dhiyaneshdk   |   701 | cves             |  1528 | info     |  1666 | http    |  4323 |
| panel     |   778 | daffainfo     |   662 | exposed-panels   |   780 | high     |  1152 | file    |    78 |
| edb       |   582 | pikpikcu      |   344 | vulnerabilities  |   519 | medium   |   835 | network |    77 |
| exposure  |   551 | pdteam        |   274 | misconfiguration |   361 | critical |   552 | dns     |    17 |
| xss       |   541 | geeknik       |   206 | technologies     |   319 | low      |   281 |         |       |
| lfi       |   519 | dwisiswant0   |   171 | exposures        |   308 | unknown  |    25 |         |       |
| wordpress |   470 | pussycat0x    |   171 | token-spray      |   236 |          |       |         |       |
| cve2021   |   369 | 0x_akoko      |   170 | workflows        |   190 |          |       |         |       |
| wp-plugin |   365 | ritikchaddha  |   163 | default-logins   |   116 |          |       |         |       |
| tech      |   357 | princechaddha |   153 | file             |    78 |          |       |         |       |
